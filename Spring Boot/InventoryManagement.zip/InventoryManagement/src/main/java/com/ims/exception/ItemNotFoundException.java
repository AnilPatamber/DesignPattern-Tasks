package com.ims.exception;

public class ItemNotFoundException extends RuntimeException{
}
